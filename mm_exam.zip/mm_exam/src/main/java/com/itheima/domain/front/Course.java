package com.itheima.domain.front;

import java.io.Serializable;
import java.util.Date;

/**
 * 科目
 * `id` varchar(100) NOT NULL,
 * `name` varchar(50) DEFAULT NULL,
 * `state` varchar(10) DEFAULT NULL COMMENT '是否显示\r\n            0 显示\r\n            1 不显示',
 * `remark` varchar(2000) DEFAULT NULL,
 * `order_no` int(11) DEFAULT NULL COMMENT '排序编号',
 * `create_by` varchar(50) DEFAULT NULL,
 * `create_dept` varchar(50) DEFAULT NULL,
 * `create_time` datetime DEFAULT NULL,
 * `update_by` varchar(50) DEFAULT NULL,
 * `update_time` datetime DEFAULT NULL,
 */
public class Course implements Serializable {
    private String id;
    private String name;
    private String state;
    private String remark;
    private Integer orderNo;
    private String createBy;
    private String createDept;
    private Date createTime;
    private String updateBy;
    private Date updateTime;

    public Course() {
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public Integer getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(Integer orderNo) {
        this.orderNo = orderNo;
    }

    public String getCreateBy() {
        return createBy;
    }

    public void setCreateBy(String createBy) {
        this.createBy = createBy;
    }

    public String getCreateDept() {
        return createDept;
    }

    public void setCreateDept(String createDept) {
        this.createDept = createDept;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getUpdateBy() {
        return updateBy;
    }

    public void setUpdateBy(String updateBy) {
        this.updateBy = updateBy;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
}
