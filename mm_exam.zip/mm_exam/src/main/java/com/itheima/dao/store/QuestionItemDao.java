package com.itheima.dao.store;

import com.itheima.domain.store.QuestionItem;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface QuestionItemDao {
    List<QuestionItem> findByQuestionId(String questionId);

    List<QuestionItem> listByQuestionId(@Param("questionId") String questionId,@Param("isRight") String isRight);
}
