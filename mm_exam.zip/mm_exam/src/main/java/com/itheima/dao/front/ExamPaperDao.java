package com.itheima.dao.front;

import com.itheima.domain.front.Course;
import com.itheima.domain.front.ExamPaper;
import com.itheima.pojo.dto.ArchivesHistoryPageDto;

import java.util.List;

public interface ExamPaperDao {
    int save(ExamPaper examPaper);

    List<ExamPaper> queryPageByMember(ArchivesHistoryPageDto archivesHistoryPageDto);
}
