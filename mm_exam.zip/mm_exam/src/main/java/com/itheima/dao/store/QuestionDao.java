package com.itheima.dao.store;

import com.itheima.domain.store.Question;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface QuestionDao {
    List<Question> findAll();

    List<Question> listByCourse(@Param("courseId") String course);
}
