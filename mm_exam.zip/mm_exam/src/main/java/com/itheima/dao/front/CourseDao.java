package com.itheima.dao.front;

import com.itheima.domain.front.Course;
import com.itheima.pojo.dto.CoursePageDto;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface CourseDao {

    List<Course> queryPage(CoursePageDto coursePageDto);

    Course selectById(@Param("id") String courseId);
}
