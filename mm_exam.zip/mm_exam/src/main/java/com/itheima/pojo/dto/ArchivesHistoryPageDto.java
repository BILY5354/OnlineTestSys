package com.itheima.pojo.dto;

/**
 *
 */
public class ArchivesHistoryPageDto {

    // 当前用户id
    private String memberId;

    private ReqPage page;

    public ArchivesHistoryPageDto() {

    }

    public ReqPage getPage() {
        return page;
    }

    public void setPage(ReqPage page) {
        this.page = page;
    }

    public String getMemberId() {
        return memberId;
    }

    public void setMemberId(String memberId) {
        this.memberId = memberId;
    }
}
