package com.itheima.pojo.dto;

/**
 * 请求 分页信息
 */
public class ReqPage {
    // 翻页大小
    private Integer pageSize = 10;
    // 第几页
    private Integer pageNum = 1;

    public ReqPage() {
    }


    public Integer getPageSize() {
        return pageSize;
    }

    public void setPageSize(Integer pageSize) {
        this.pageSize = pageSize;
    }

    public Integer getPageNum() {
        return pageNum;
    }

    public void setPageNum(Integer pageNum) {
        this.pageNum = pageNum;
    }
}
