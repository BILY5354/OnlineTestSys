package com.itheima.pojo.constant;

/**
 * yes no枚举
 */
public enum YESORNOEnum {
    YES("1", "是"), NO("0", "否");
    String value;
    String description;

    YESORNOEnum(String value, String description) {
        this.value = value;
        this.description = description;
    }

    public String getValue() {
        return value;
    }

    public String getDescription() {
        return description;
    }
}
