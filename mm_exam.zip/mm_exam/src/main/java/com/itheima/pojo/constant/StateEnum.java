package com.itheima.pojo.constant;

/**
 * 状态枚举
 */
public enum StateEnum {
    VALID("1", "有效"), INVALID("0", "无效");
    String value;
    String description;

    StateEnum(String value, String description) {
        this.value = value;
        this.description = description;
    }

    public String getValue() {
        return value;
    }

    public String getDescription() {
        return description;
    }
}
