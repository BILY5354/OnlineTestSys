package com.itheima.pojo.dto;

/**
 * 大类分页请求
 */
public class CoursePageDto {

    private ReqPage page;


    public CoursePageDto() {

    }

    public ReqPage getPage() {
        return page;
    }

    public void setPage(ReqPage page) {
        this.page = page;
    }

}
