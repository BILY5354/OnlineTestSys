package com.itheima.web.controller.front;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.itheima.domain.front.Course;
import com.itheima.domain.front.ExamPaper;
import com.itheima.domain.front.ExamQuestion;
import com.itheima.domain.store.Question;
import com.itheima.pojo.constant.StateEnum;
import com.itheima.pojo.dto.ArchivesHistoryPageDto;
import com.itheima.pojo.dto.CoursePageDto;
import com.itheima.pojo.dto.ReqPage;
import com.itheima.web.controller.BaseServlet;
import com.itheima.web.controller.Code;
import com.itheima.web.controller.Result;
import com.sun.org.apache.bcel.internal.generic.IF_ACMPEQ;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.EOFException;
import java.io.IOException;
import java.util.List;


@WebServlet("/exam/*")
public class ExamServlet extends BaseServlet {
    public static final Integer QUESTION_NUM = 10;

    public Result getPaper(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String courseId = request.getParameter("course");

        if (StringUtils.isBlank(courseId)) {
            // 抛出异常
            throw new RuntimeException("请输入课程");
        }

        Course course = courseService.selectById(courseId);
        if (null == course || !StateEnum.VALID.getValue().equals(course.getState())) {
            throw new RuntimeException("课程不存在或已下线");
        }
        List<Question> questionList = examService.selectPaper(courseId, QUESTION_NUM);

//        List<Question> questionList = examService.getPaper();
        return new Result("试卷生成成功", questionList);
    }

    public Result applyPaper(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //  得到全部请求的json数据
        String json = JSONObject.parseObject(request.getInputStream(), String.class);
        //  将json数据转为对象
        JSONObject jsonObject = JSON.parseObject(json);
        System.out.println(jsonObject);
        //  获取当前提交试卷人id
        String memberId = jsonObject.getObject("memberId", String.class);
        //  获取当前提交的试卷信息
        JSONArray jsonArray = jsonObject.getJSONArray("results");
        List<ExamQuestion> examQuestionList = jsonArray.toJavaList(ExamQuestion.class);

        /*System.out.println(memberId);
        System.out.println(examQuestionList);
        return null;*/
        String courseId = jsonObject.getString("courseId");
        if (StringUtils.isBlank(courseId)) {
            return new Result("试卷提交失败！", false, null, Code.FAIL);
        }
        boolean flag = examService.applyPaper(memberId, courseId,examQuestionList);
        return new Result("试卷提交成功！", flag);
    }

    /**
     * 分页获取大类
     *
     * @param request
     * @return
     */
    public Result pageCourse(HttpServletRequest request, HttpServletResponse response) throws IOException {
        CoursePageDto coursePageDto = JSONObject.parseObject(request.getInputStream(), CoursePageDto.class);
        // 获取参数
        if (coursePageDto == null) {
            coursePageDto = new CoursePageDto();
        }
        ReqPage page = coursePageDto.getPage();
        if (page == null) {
            coursePageDto.setPage(new ReqPage());
        }
        PageInfo<Course> pageInfo = courseService.queryPage(coursePageDto);
        return new Result(pageInfo);
    }


}