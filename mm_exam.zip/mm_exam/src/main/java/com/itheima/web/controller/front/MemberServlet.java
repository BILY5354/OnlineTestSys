package com.itheima.web.controller.front;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.PageInfo;
import com.itheima.domain.front.Course;
import com.itheima.domain.front.ExamPaper;
import com.itheima.domain.front.Member;
import com.itheima.pojo.dto.ArchivesHistoryPageDto;
import com.itheima.pojo.dto.ReqPage;
import com.itheima.pojo.vo.ExamPaperVO;
import com.itheima.web.controller.BaseServlet;
import com.itheima.web.controller.Code;
import com.itheima.web.controller.Result;
import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;

@WebServlet("/member/*")
public class MemberServlet extends BaseServlet {
    public Result register(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Member member = getData(request, Member.class);
        boolean flag = memberService.register(member);
        return new Result("注册成功", null);
    }

    public Result login(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Member member = getData(request, Member.class);
        member = memberService.login(member.getEmail(), member.getPassword());

        if (member != null) {
            return new Result("登录成功", member);
        } else {
            return new Result("用户名密码错误，请重试", false, null, Code.LOGIN_FAIL);
        }
    }

    public Result logout(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Member member = getData(request, Member.class);
        boolean flag = memberService.logout(member.getId());

        if (flag) {
            return new Result("退出成功", flag);
        } else {
            return new Result("", false, flag, Code.LOGOUT_FAIL);
        }
    }

    public Result checkLogin(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Member member = getData(request, Member.class);
        String nickName = memberService.getLoginInfo(member.getId());
        return new Result("", nickName);
    }

    public Result myExaminationPaper(HttpServletRequest request, HttpServletResponse response) throws IOException, InvocationTargetException, IllegalAccessException {
        ArchivesHistoryPageDto archivesHistoryPageDto = JSONObject.parseObject(request.getInputStream(), ArchivesHistoryPageDto.class);
        // 获取参数
        if (archivesHistoryPageDto == null || StringUtils.isBlank(archivesHistoryPageDto.getMemberId())) {
            throw new RuntimeException("请输入用户信息");
        }
        ReqPage page = archivesHistoryPageDto.getPage();
        if (page == null) {
            archivesHistoryPageDto.setPage(new ReqPage());
        }
        PageInfo pageInfo = examinationPaperService.queryPage(archivesHistoryPageDto);
        ArrayList<ExamPaperVO> examPaperVOS = new ArrayList<>();
        for (ExamPaper examPaper : (ArrayList<ExamPaper>) pageInfo.getList()) {
            ExamPaperVO examPaperVO = new ExamPaperVO();
            BeanUtils.copyProperties( examPaperVO,examPaper);
            if (StringUtils.isNotBlank(examPaper.getCourseId())) {
                Course course = courseService.selectById(examPaper.getCourseId());
                if (null != course) {
                    examPaperVO.setCourseName(course.getName());
                }
            }
            examPaperVOS.add(examPaperVO);
        }
        pageInfo.setList(examPaperVOS);
        return new Result(pageInfo);
    }
}
/*@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //  收集数据
        String json = JSON.parseObject(request.getInputStream(), String.class);
        //  实体类
        Member member= JSON.parseObject(json, Member.class);
        //  调用逻辑API
        boolean flag = memberService.register(member);
        //  返回结果
        Result result = new Result("注册成功", null);
        response.setContentType("application/json;charset=utf-8");
        JSON.writeJSONString(response.getOutputStream(),result);
    }*/