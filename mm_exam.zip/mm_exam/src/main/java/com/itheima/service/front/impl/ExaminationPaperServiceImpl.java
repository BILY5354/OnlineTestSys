package com.itheima.service.front.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.itheima.dao.front.ExamPaperDao;
import com.itheima.dao.store.QuestionDao;
import com.itheima.domain.front.Course;
import com.itheima.domain.front.ExamPaper;
import com.itheima.domain.store.Question;
import com.itheima.factory.MapperFactory;
import com.itheima.pojo.dto.ArchivesHistoryPageDto;
import com.itheima.service.front.ExaminationPaperService;
import com.itheima.utils.TransactionUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

public class ExaminationPaperServiceImpl implements ExaminationPaperService {

    @Override
    public PageInfo<ExamPaper> queryPage(ArchivesHistoryPageDto archivesHistoryPageDto) {
        SqlSession sqlSession = null;
        try {
            //1.获取SqlSession
            sqlSession = MapperFactory.getSqlSession();
            //2.获取Dao
            ExamPaperDao examPaperDao = MapperFactory.getMapper(sqlSession, ExamPaperDao.class);
            PageHelper.startPage(archivesHistoryPageDto.getPage().getPageNum(), archivesHistoryPageDto.getPage().getPageSize());
            List<ExamPaper> all = examPaperDao.queryPageByMember(archivesHistoryPageDto);
            PageInfo pageInfo = new PageInfo(all);
            return pageInfo;

        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
            //记录日志
        } finally {
            try {
                TransactionUtil.close(sqlSession);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
