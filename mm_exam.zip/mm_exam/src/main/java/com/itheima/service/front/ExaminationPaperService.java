package com.itheima.service.front;

import com.github.pagehelper.PageInfo;
import com.itheima.domain.front.ExamPaper;
import com.itheima.pojo.dto.ArchivesHistoryPageDto;

public interface ExaminationPaperService {
    PageInfo<ExamPaper> queryPage(ArchivesHistoryPageDto archivesHistoryPageDto);
}
