package com.itheima.service.front;

import com.github.pagehelper.PageInfo;
import com.itheima.domain.front.Course;
import com.itheima.pojo.dto.CoursePageDto;

public interface CourseService {
    PageInfo<Course> queryPage(CoursePageDto coursePageDto);

    Course selectById(String courseId);
}
