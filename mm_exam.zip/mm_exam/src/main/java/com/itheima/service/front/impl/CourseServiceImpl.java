package com.itheima.service.front.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.itheima.dao.front.CourseDao;
import com.itheima.dao.store.QuestionDao;
import com.itheima.domain.front.Course;
import com.itheima.domain.store.Question;
import com.itheima.factory.MapperFactory;
import com.itheima.pojo.dto.CoursePageDto;
import com.itheima.service.front.CourseService;
import com.itheima.utils.TransactionUtil;
import org.apache.ibatis.session.SqlSession;

import java.util.List;

/**
 * 学科service
 */
public class CourseServiceImpl implements CourseService {
    @Override
    public PageInfo<Course> queryPage(CoursePageDto coursePageDto) {
        SqlSession sqlSession = null;
        try{
            sqlSession = MapperFactory.getSqlSession();
            //2.获取Dao
            CourseDao courseDao = MapperFactory.getMapper(sqlSession, CourseDao.class);
            //3.调用Dao层操作
            PageHelper.startPage(coursePageDto.getPage().getPageNum(),coursePageDto.getPage().getPageSize());
            List<Course> all = courseDao.queryPage(coursePageDto);
            PageInfo pageInfo = new PageInfo(all);
            return pageInfo;
        }catch (Exception e){
            e.printStackTrace();
            throw new RuntimeException(e);
            //记录日志
        }finally {
            try {
                TransactionUtil.close(sqlSession);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }

    @Override
    public Course selectById(String courseId) {
        SqlSession sqlSession = null;
        try{
            sqlSession = MapperFactory.getSqlSession();
            //2.获取Dao
            CourseDao courseDao = MapperFactory.getMapper(sqlSession, CourseDao.class);
            return courseDao.selectById(courseId);
        }catch (Exception e){
            e.printStackTrace();
            throw new RuntimeException(e);
            //记录日志
        }finally {
            try {
                TransactionUtil.close(sqlSession);
            }catch (Exception e){
                e.printStackTrace();
            }
        }
    }
}
