package com.itheima.service.front.impl;

import com.itheima.dao.front.ExamPaperDao;
import com.itheima.dao.front.ExamQuestionDao;
import com.itheima.dao.store.QuestionDao;
import com.itheima.dao.store.QuestionItemDao;
import com.itheima.domain.front.*;
import com.itheima.domain.store.Question;
import com.itheima.domain.store.QuestionItem;
import com.itheima.factory.MapperFactory;
import com.itheima.pojo.constant.YESORNOEnum;
import com.itheima.service.front.ExamService;
import com.itheima.utils.TransactionUtil;
import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;

import java.util.*;
import java.util.stream.Collectors;

public class ExamServiceImpl implements ExamService {
    @Override
    public List<Question> getPaper() {
        SqlSession sqlSession = null;
        try {
            //1.获取SqlSession
            sqlSession = MapperFactory.getSqlSession();
            //2.获取Dao
            QuestionDao questionDao = MapperFactory.getMapper(sqlSession, QuestionDao.class);
            List<Question> questionList = questionDao.findAll();
            return questionList;
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
            //记录日志
        } finally {
            try {
                TransactionUtil.close(sqlSession);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public boolean applyPaper(String memberId,String courseId, List<ExamQuestion> examQuestionList) {
        SqlSession sqlSession = null;
        try {
            boolean flag = true;
            //1.获取SqlSession
            sqlSession = MapperFactory.getSqlSession();
            //2.获取Dao
            ExamPaperDao examPaperDao = MapperFactory.getMapper(sqlSession, ExamPaperDao.class);
            ExamQuestionDao examQuestionDao = MapperFactory.getMapper(sqlSession, ExamQuestionDao.class);
            QuestionItemDao questItemDao = MapperFactory.getMapper(sqlSession, QuestionItemDao.class);
            //3.提交保存的试卷信息
            ExamPaper examPaper = new ExamPaper();
            String paperId = UUID.randomUUID().toString();
            examPaper.setId(paperId);
            examPaper.setApplyTime(new Date());
            examPaper.setMemberId(memberId);
            examPaper.setState("1");
            examPaper.setCourseId(courseId);

            // 计算分数
            int totalNum = examQuestionList.size();
            // 没个题目的分数
            int score = 100 / totalNum;
            int lastScore = score;
            // 如果存在剩数 全部给最后一个题目
            int surplusScope = 100 % totalNum;
            if (surplusScope > 0) {
                lastScore += surplusScope;
            }

            //flag = flag && examPaperDao.save(examPaper) > 0;
            //4.提交保存的试卷中的所有题目对应的答案信息
//            for (ExamQuestion eq : examQuestionList) {
//                eq.setId(UUID.randomUUID().toString());
//                eq.setExamPaperId(paperId);
//                flag = flag && examQuestionDao.save(eq) > 0;
//                // 计算分数
//            }
            int allScore = 0;
            for (int i = 0; i < totalNum; i++) {
                ExamQuestion examQuestion = examQuestionList.get(i);
                examQuestion.setId(UUID.randomUUID().toString());
                examQuestion.setExamPaperId(paperId);
                // 存储
                flag = flag && examQuestionDao.save(examQuestion) > 0;
                // 查找答案
                // 获取所有答案
                List<QuestionItem> questItems = questItemDao.listByQuestionId(examQuestion.getQuestionId(), YESORNOEnum.YES.getValue());
                if (questItems.isEmpty()) {
                    continue;
                }
                String answer = examQuestion.getAnswer();
                if (StringUtils.isBlank(answer)) {
                    continue;
                }
                String[] selectors = answer.split(",");
                //选择数量不一致的时候
                if (selectors.length != questItems.size()) {
                    continue;
                }
                boolean isAllRight = true;
                for (QuestionItem questItem : questItems) {
                    boolean exist = false;
                    for (int j = 0; j < selectors.length; j++) {
                        if (questItem.getId().equals(selectors[j])) {
                            exist = true;
                            break;
                        }
                    }
                    //  如果没有正确答案则退出
                    if (!exist) {
                        isAllRight = false;
                        break;
                    }
                }
                if (isAllRight) {
                    // 最后一个题目
                    if (i == totalNum - 1) {
                        allScore += lastScore;
                    } else {
                        allScore += score;
                    }
                }


            }
            examPaper.setScore(allScore);
            flag = flag && examPaperDao.save(examPaper) > 0;
            TransactionUtil.commit(sqlSession);
            return flag;
        } catch (Exception e) {
            TransactionUtil.rollback(sqlSession);
            throw new RuntimeException(e);
            //记录日志
        } finally {
            try {
                TransactionUtil.close(sqlSession);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 获取试卷
     *
     * @param course
     * @param questionNum
     * @return
     */
    @Override
    public List<Question> selectPaper(String course, Integer questionNum) {
        SqlSession sqlSession = null;
        try {
            //1.获取SqlSession
            sqlSession = MapperFactory.getSqlSession();
            //2.获取Dao
            QuestionDao questionDao = MapperFactory.getMapper(sqlSession, QuestionDao.class);
            List<Question> questionList = questionDao.listByCourse(course);

            if (questionList.size() <= questionNum) {
                return questionList;
            }
            Random random = new Random();

            HashMap<String, Question> result = new HashMap<>();
            int existSize = questionList.size();
            while (result.size() < questionNum) {
                int i = random.nextInt(existSize);

                Question question = questionList.get(i);
                String id = question.getId();

                Question selectItem = result.get(id);
                if (selectItem == null) {
                    result.put(id, question);
                }
            }
            return result.values().stream().collect(Collectors.toList());
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException(e);
            //记录日志
        } finally {
            try {
                TransactionUtil.close(sqlSession);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
